@extends('admin-panel.includes.master')
@section('content')
<section class="content">
    <div class="">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <h2>Ayodhya Dham Tample Add</h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{route('adminDashboard')}}"><i class="zmdi zmdi-home"></i> Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="{{route('adminAyodhyaDhamTempleList')}}"> Ayodhya Dham Tample List</a></li>
                        <li class="breadcrumb-item active">Ayodhya Dham Tample Add</li>
                    </ul>
                    <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                </div>
                <div class="col-lg-5 col-md-6 col-sm-12">
                    <button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i class="zmdi zmdi-arrow-right"></i></button>
                </div>
            </div>
        </div>
       
        <div class="container-fluid">
            <form  action="{{route('adminAyodhyaDhamSaveTemple')}}" method="post" enctype="multipart/form-data">
                @csrf
                <div class="row" >
                <div class="col-lg-6 col-md-12">
                    <label for="Name">Name<span class="text-danger">*</span></label>
                    <div class="form-group">                                
                        <input type="text" id="name" name="name" class="form-control" placeholder="Name" value="{{old('name')}}" required>
                    </div>
                    @if ($errors->has('name'))
                        <span class="text-danger">{{ $errors->first('name') }}</span>
                    @endif 
                </div>
                <div class="col-lg-6 col-md-12">
                    <label for="Open timings">Open timings <span class="text-danger">*</span></label>
                    <div class="form-group">                                
                        <input type="text" id="open_time" name="open_time" class="form-control" placeholder="Open timings" value="{{old('open_time')}}" required>
                    </div>
                    @if ($errors->has('open_time'))
                        <span class="text-danger">{{ $errors->first('open_time') }}</span>
                    @endif 
                </div>
                <div class="col-lg-6 col-md-12">
                    <label for="Address">Address <span class="text-danger">*</span></label>
                    <div class="form-group">                                
                        <input type="text" id="address" name="address" class="form-control" placeholder="Address" value="{{old('address')}}" required>
                    </div>
                    @if ($errors->has('address'))
                        <span class="text-danger">{{ $errors->first('address') }}</span>
                    @endif 
                </div>
                <div class="col-lg-6 col-md-12">
                    <label for="Via Railway Station">Via Railway Station <span class="text-danger">*</span></label>
                    <div class="form-group">                                
                        <input type="text" id="via_railway_station" name="via_railway_station" class="form-control" placeholder="Via Railway Station" value="{{old('via_railway_station')}}" required>
                    </div>
                    @if ($errors->has('via_railway_station'))
                        <span class="text-danger">{{ $errors->first('via_railway_station') }}</span>
                    @endif 
                </div>
                <div class="col-lg-6 col-md-12">
                    <label for="Estimated Time">Estimated Time <span class="text-danger">*</span></label>
                    <div class="form-group">                                
                        <input type="text" id="estimate_time" name="estimate_time" class="form-control" placeholder="Estimated Time" value="{{old('estimate_time')}}" required>
                    </div>
                    @if ($errors->has('estimate_time'))
                        <span class="text-danger">{{ $errors->first('estimate_time') }}</span>
                    @endif 
                </div>
                <div class="col-lg-6 col-md-12">
                    <label for="Estimated Time">Scan QR for location</label>
                    <div class="form-group">                                
                        <input type="file" id="qr_location" name="qr_location" class="form-control" accept=".png, .jpg, .jpeg">
                    </div>
                    @if ($errors->has('qr_location'))
                        <span class="text-danger">{{ $errors->first('qr_location') }}</span>
                    @endif 
                </div>
                <div class="col-lg-6 col-md-12">
                    <label for="Photo">Photo <span class="text-danger">*</span></label>
                    
                    <div class="form-group">                                
                        <input type="file" id="photo" name="photo" class="form-control" accept=".png, .jpg, .jpeg" required>
                    </div>
                    @if ($errors->has('photo'))
                        <span class="text-danger">{{ $errors->first('photo') }}</span>
                    @endif   
                </div> 
                <div class="col-lg-12 col-md-12">
                    <label for="Description">Description</label>
                    <div class="form-group">                                
                        <textarea class="form-control editor" name="description">{{old('description')}}</textarea>
                    </div>
                    @if ($errors->has('description'))
                        <span class="text-danger">{{ $errors->first('description') }}</span>
                    @endif 
                </div>   
            </div>
                <button type="submit" class="btn btn-primary">SUBMIT</button>
            </form>
        </div>
    </div>
</section>
@stop