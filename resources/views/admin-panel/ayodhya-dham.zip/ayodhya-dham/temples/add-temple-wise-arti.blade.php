@extends('admin-panel.includes.master')
@section('content')
<section class="content">
    <div class="">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <h2>Temple Wise Arti List</h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{route('adminDashboard')}}"><i class="zmdi zmdi-home"></i> Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="{{route('adminAyodhyaDhamTempleList')}}"> Temple Wise Arti List</a></li>
                        <li class="breadcrumb-item active">Temple Wise Arti Add</li>
                    </ul>
                    <button class="btn btn-primary btn-icon mobile_menu" type="button"><i class="zmdi zmdi-sort-amount-desc"></i></button>
                </div>
                <div class="col-lg-5 col-md-6 col-sm-12">
                    <button class="btn btn-primary btn-icon float-right right_icon_toggle_btn" type="button"><i class="zmdi zmdi-arrow-right"></i></button>
                </div>
            </div>
        </div>
       
        <div class="container-fluid">
            <form  action="{{route('adminAyodhyaDhamSaveTemple')}}" method="post" enctype="multipart/form-data">
                @csrf
                <div class="row" >
                <div class="col-lg-6 col-md-12">
                    <label for="Name">Name<span class="text-danger">*</span></label>
                    <div class="form-group">                                
                        <input type="text" id="name" name="name" class="form-control" placeholder="Name" value="{{old('name')}}" required>
                    </div>
                    @if ($errors->has('name'))
                        <span class="text-danger">{{ $errors->first('name') }}</span>
                    @endif 
                </div>
                <div class="col-lg-6 col-md-12">
                    <label for="Open timings">Open time <span class="text-danger">*</span></label>
                    <div class="form-group">                                
                        <input type="time" id="open_time" name="open_time" class="form-control" placeholder="Open timings" value="{{old('open_time')}}" required>
                    </div>
                    @if ($errors->has('open_time'))
                        <span class="text-danger">{{ $errors->first('open_time') }}</span>
                    @endif 
                </div>
                <div class="col-lg-6 col-md-12">
                    <label for="Close time">Close Time <span class="text-danger">*</span></label>
                    <div class="form-group">                                
                        <input type="time" id="close_time" name="close_time" class="form-control" placeholder="Close time" value="{{old('close_time')}}" required>
                    </div>
                    @if ($errors->has('close_time'))
                        <span class="text-danger">{{ $errors->first('close_time') }}</span>
                    @endif 
                </div>
            </div>
                <button type="submit" class="btn btn-primary">SUBMIT</button>
            </form>
        </div>
    </div>
</section>
@stop